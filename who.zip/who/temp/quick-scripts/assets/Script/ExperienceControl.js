(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/ExperienceControl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ea488Xhdi9LcYrO1gRbX/Dk', 'ExperienceControl', __filename);
// Script/ExperienceControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerControl_1 = require("./PlayerControl");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ExperienceControl = /** @class */ (function (_super) {
    __extends(ExperienceControl, _super);
    function ExperienceControl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.playerNode = null;
        _this.maxexp = 100;
        _this.currentexp = 0;
        return _this;
    }
    ExperienceControl.prototype.onLoad = function () {
        this.updateProgressBar();
    };
    ExperienceControl.prototype.updateProgressBar = function () {
        if (this.getComponent(cc.ProgressBar)) {
            var percentage = this.currentexp / this.maxexp;
            this.getComponent(cc.ProgressBar).progress = percentage;
        }
    };
    ExperienceControl.prototype.start = function () {
    };
    ExperienceControl.prototype.update = function (dt) {
        var play = this.playerNode.getComponent(PlayerControl_1.default);
        this.currentexp = play.player.exp;
        this.updateProgressBar();
    };
    __decorate([
        property(cc.Node)
    ], ExperienceControl.prototype, "playerNode", void 0);
    ExperienceControl = __decorate([
        ccclass
    ], ExperienceControl);
    return ExperienceControl;
}(cc.Component));
exports.default = ExperienceControl;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ExperienceControl.js.map
        