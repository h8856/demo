(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/kuwuControl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'de45e9cQT5B2LJDoPm8eyOV', 'kuwuControl', __filename);
// Script/kuwuControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var kuwuControl = /** @class */ (function (_super) {
    __extends(kuwuControl, _super);
    function kuwuControl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bullet_hurt = 50;
        _this.player = null;
        _this.direction = cc.v2(0, 0);
        _this.speed = 0;
        return _this;
    }
    kuwuControl.prototype.onLoad = function () {
        this.player = cc.find("player");
        cc.director.getCollisionManager().enabled = true;
    };
    kuwuControl.initialize = function (direction, Vec2, speed, number) {
        throw new Error("Method not implemented.");
    };
    // 初始化方法  
    kuwuControl.prototype.initialize = function (direction, speed) {
        this.direction = direction.normalize(); // 归一化方向向量  
        this.speed = speed;
        var rigidBody = this.getComponent(cc.RigidBody);
        if (rigidBody) {
            rigidBody.linearVelocity = this.direction.mul(this.speed); // 设置物理速度  
        }
    };
    kuwuControl.prototype.update = function (dt) {
        this.node.rotation += 360 * dt;
        // 判断子弹是否超出屏幕或者其他逻辑  
        if (Math.abs(this.node.position.y - this.player.position.y) > 1500 || Math.abs(this.node.position.x - this.player.position.x) > 1500) {
            this.node.destroy(); // 超出屏幕则销毁子弹  
            // cc.log("子弹飞出屏幕")
        }
    };
    kuwuControl.prototype.onBeginContact = function (contact, self, other) {
    };
    kuwuControl = __decorate([
        ccclass
    ], kuwuControl);
    return kuwuControl;
}(cc.Component));
exports.default = kuwuControl;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=kuwuControl.js.map
        