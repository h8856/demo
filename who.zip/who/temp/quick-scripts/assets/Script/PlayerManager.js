(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/PlayerManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dbcbaWJXONNJ69CnnIaqicF', 'PlayerManager', __filename);
// Script/PlayerManager.ts

// import ManagerBase from "./ManagerBase";  
// const {ccclass, property} = cc._decorator;  
// @ccclass  
// export default class PlayerManager extends ManagerBase {  
//     static instance: PlayerManager;  
//     onLoad() {  
//         super.onLoad();  
//         if (PlayerManager.instance) {  
//             // 如果已经存在实例，则销毁此节点  
//             cc.warn("PlayerManager instance already exists. Destroying this instance.");  
//             this.node.destroy();  
//             return;  
//         }  
//         PlayerManager.instance = this;   
//         cc.log("PlayerManager instance created.");  
//     }  
//     start() {  
//         cc.log("PlayerManager started.");  
//     }  
//     update (dt) {  
//         // 可以添加一些逻辑  
//     }  
//     // 注册接收器  
//     RegisterReceiver(receiver) {  
//         cc.log("Receiver registered:", receiver);  
//         // 添加接收器处理逻辑  
//     }  
// }

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PlayerManager.js.map
        