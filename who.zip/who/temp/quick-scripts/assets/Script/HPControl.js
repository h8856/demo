(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/HPControl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b0347j/7FpKJpOV2GBPuRK6', 'HPControl', __filename);
// Script/HPControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerControl_1 = require("./PlayerControl");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.playerNode = null;
        _this.maxHealth = 100;
        // 当前生命值
        _this._currentHealth = 100;
        return _this;
    }
    Object.defineProperty(NewClass.prototype, "currentHealth", {
        get: function () {
            return this._currentHealth;
        },
        set: function (value) {
            // 限制当前生命值范围在0到最大生命值之间
            this._currentHealth = Math.min(Math.max(value, 0), this.maxHealth);
            this.updateProgressBar();
        },
        enumerable: true,
        configurable: true
    });
    NewClass.prototype.onLoad = function () {
        this.updateProgressBar();
    };
    NewClass.prototype.updateProgressBar = function () {
        if (this.getComponent(cc.ProgressBar)) {
            var percentage = this._currentHealth / this.maxHealth;
            this.getComponent(cc.ProgressBar).progress = percentage;
        }
    };
    NewClass.prototype.takeDamage = function (damage) {
        this.currentHealth -= damage;
    };
    NewClass.prototype.heal = function (healAmount) {
        this.currentHealth += healAmount;
    };
    NewClass.prototype.start = function () {
    };
    NewClass.prototype.update = function (dt) {
        if (this.playerNode) {
            var play = this.playerNode.getComponent(PlayerControl_1.default);
            if (play && play.player) {
                this._currentHealth = play.player.health; // 确保 play.player 不为 null  
                this.updateProgressBar();
            }
            else {
                console.error("PlayerControl component or player is null.");
            }
        }
        else {
            console.error("PlayerNode reference is null.");
        }
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "playerNode", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=HPControl.js.map
        