(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/TimeMnanger.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bf34cCrot9PPbTlBUiY+xRH', 'TimeMnanger', __filename);
// Script/TimeMnanger.ts

Object.defineProperty(exports, "__esModule", { value: true });
// TimerManager.ts  
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var TimerManager = /** @class */ (function (_super) {
    __extends(TimerManager, _super);
    function TimerManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.time = 0; // 当前计时器  
        _this.spawnInterval = 1;
        return _this;
    }
    TimerManager_1 = TimerManager;
    Object.defineProperty(TimerManager, "instance", {
        get: function () {
            if (!this._instance) {
                this._instance = new TimerManager_1();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    TimerManager.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    TimerManager.prototype.update = function (dt) {
    };
    // 重置计时器  
    TimerManager.prototype.resetTimer = function () {
        this.time = 0;
    };
    var TimerManager_1;
    TimerManager._instance = null;
    TimerManager = TimerManager_1 = __decorate([
        ccclass
    ], TimerManager);
    return TimerManager;
}(cc.Component));
exports.default = TimerManager;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TimeMnanger.js.map
        