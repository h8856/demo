(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/MapControl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e96eewwdJRN6YaMk8ZSWC28', 'MapControl', __filename);
// Script/MapControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerControl_1 = require("./PlayerControl");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MapControl = /** @class */ (function (_super) {
    __extends(MapControl, _super);
    function MapControl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        return _this;
    }
    MapControl.prototype.onLoad = function () {
    };
    MapControl.prototype.start = function () {
    };
    MapControl.prototype.update = function (dt) {
        this.bgcontrol();
    };
    MapControl.prototype.bgcontrol = function () {
        for (var _i = 0, _a = this.node.children; _i < _a.length; _i++) {
            var child = _a[_i];
            this.x = child.x;
            this.y = child.y;
            this.posix = this.player.node.position.x;
            this.posiy = this.player.node.position.y;
            var disx = this.posix - this.x;
            var disy = this.posiy - this.y;
            if (Math.abs(disx) >= 1800) {
                if (disx > 0) {
                    disx = 1024;
                }
                if (disx < 0) {
                    disx = -1024;
                }
                child.x += disx * 3;
            }
            if (Math.abs(disy) >= 704) {
                if (disy > 0) {
                    disy = 704;
                }
                if (disy < 0) {
                    disy = -704;
                }
                child.y += disy * 2;
            }
        }
    };
    __decorate([
        property(PlayerControl_1.default)
    ], MapControl.prototype, "player", void 0);
    MapControl = __decorate([
        ccclass
    ], MapControl);
    return MapControl;
}(cc.Component));
exports.default = MapControl;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapControl.js.map
        