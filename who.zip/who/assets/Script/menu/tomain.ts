const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

  

    main(){
        cc.director.loadScene("main");
    }
    onLoad () {

    }

    start () {

    }

    update (dt) {
        
    }
}
