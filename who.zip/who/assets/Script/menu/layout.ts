const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    close(){
        this.node.active = false;
    }
    onLoad () {

    }

    start () {

    }

    update (dt) {
        
    }
}
