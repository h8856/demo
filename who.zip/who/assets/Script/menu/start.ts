const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    Tostart(){
        cc.director.loadScene("whos");
    }
  
    onLoad () {

    }

    start () {

    }

    update (dt) {
        
    }
}
