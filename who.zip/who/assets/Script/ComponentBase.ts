import Message from "./Message";

const {ccclass, property} = cc._decorator;

@ccclass
export default class ComponentBase extends cc.Component {

    ReceiveMessage(message:Message){
        
    }
    
}
