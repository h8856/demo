"use strict";
cc._RF.push(module, 'c3923mkTcRO17XLl+MIAZqn', 'MessageCenter');
// Script/MessageCenter.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Message_1 = require("./Message");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var MessageCenter = /** @class */ (function () {
    function MessageCenter() {
    }
    //发送消息
    MessageCenter.SendMessage = function (msg) {
        for (var _i = 0, _a = this.Managers; _i < _a.length; _i++) {
            var manager = _a[_i];
            manager.ReceiveMessage(msg);
        }
    };
    MessageCenter.SendCustomMessage = function (type, Command, content) {
        var msg = new Message_1.default(type, Command, content);
        this.SendMessage(msg);
    };
    // 管理类列表
    MessageCenter.Managers = [];
    MessageCenter = __decorate([
        ccclass
    ], MessageCenter);
    return MessageCenter;
}());
exports.default = MessageCenter;

cc._RF.pop();