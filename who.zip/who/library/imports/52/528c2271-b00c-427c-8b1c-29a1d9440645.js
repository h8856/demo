"use strict";
cc._RF.push(module, '528c2JxsAxCfIscKaHZRAZF', 'GameManager ');
// Script/class/GameManager .ts

var GameManager = /** @class */ (function () {
    function GameManager() {
        this.isPaused = false;
    }
    // 切换暂停状态  
    GameManager.prototype.togglePause = function () {
        this.isPaused = !this.isPaused;
        if (this.isPaused) {
            this.pauseGame();
        }
        else {
            this.resumeGame();
        }
    };
    // 暂停游戏  
    GameManager.prototype.pauseGame = function () {
        cc.director.pause();
        this.showPauseMenu();
    };
    // 恢复游戏  
    GameManager.prototype.resumeGame = function () {
        cc.director.resume();
        this.hidePauseMenu();
    };
    GameManager.prototype.showPauseMenu = function () {
        // 显示暂停菜单的逻辑  
    };
    GameManager.prototype.hidePauseMenu = function () {
        // 隐藏暂停菜单的逻辑  
    };
    return GameManager;
}());

cc._RF.pop();