"use strict";
cc._RF.push(module, '46ab6ssiHtFDaUqh0iynliD', 'HiddenJoystick');
// Script/HiddenJoystick.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerControl_1 = require("./PlayerControl");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var HiddenJoystick = /** @class */ (function (_super) {
    __extends(HiddenJoystick, _super);
    function HiddenJoystick() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.moveSpeed = 200; // 玩家移动速度  
        _this.player = null;
        _this.touchPosition = null; // 触摸起始位置  
        _this.movePosition = null; // 当前触摸位置  
        _this.isTouching = false; // 控制是否正在触摸  
        return _this;
    }
    HiddenJoystick.prototype.onLoad = function () {
        // 绑定触摸事件  
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
        // 获取玩家节点，确保路径正确  
        // 根据实际路径调整  
        if (this.player) {
            var a = this.node.getComponent(PlayerControl_1.default);
            // this.moveSpeed = a.movespeed();
        }
    };
    HiddenJoystick.prototype.onTouchStart = function (event) {
        this.isTouching = true; // 开始触摸  
        this.touchPosition = event.getLocation();
        this.movePosition = this.touchPosition;
        // // 将触摸位置转换为摇杆的局部坐标  
        // const touchLocalPosition = this.node.convertToNodeSpaceAR(this.touchPosition);  
        // this.yaogan.position = touchLocalPosition;  
    };
    HiddenJoystick.prototype.onTouchMove = function (event) {
        this.movePosition = event.getLocation(); // 更新当前触摸位置  
    };
    HiddenJoystick.prototype.onTouchEnd = function () {
        this.isTouching = false; // 结束触摸  
    };
    HiddenJoystick.prototype.updateJoystick = function () {
        if (!this.touchPosition || !this.movePosition)
            return; // 确保触摸位置有效  
        var delta = this.movePosition.sub(this.touchPosition); // 计算触摸点与玩家的偏移量  
        var distance = delta.mag(); // 计算距离  
        // 设置移动的最大半径  
        var maxDistance = 281; // 最大距离，可以根据需要调整  
        if (distance > maxDistance) {
            delta.normalize(); // 归一化方向向量  
            delta.mul(maxDistance); // 限制在最大距离  
        }
        // 更新玩家位置  
        var direction = delta.normalize(); // 计算方向向量  
        this.player.position = this.player.position.add(direction.mul(this.moveSpeed * cc.director.getDeltaTime()));
        // 计算玩家旋转角度（参数交换）   
        var angle = Math.atan2(delta.y, delta.x) * (180 / Math.PI); // 交换参数  
        this.player.angle = angle + 90; // 更新玩家的旋转
        return direction;
    };
    HiddenJoystick.prototype.update = function (dt) {
        if (this.isTouching) {
            this.updateJoystick(); // 调用更新摇杆的方法  
            // 直接设置摄像机位置为玩家位置  
            cc.Camera.main.node.position = cc.v2(this.player.position.x - 480, this.player.position.y - 320);
        }
    };
    __decorate([
        property
    ], HiddenJoystick.prototype, "moveSpeed", void 0);
    __decorate([
        property(cc.Node)
    ], HiddenJoystick.prototype, "player", void 0);
    HiddenJoystick = __decorate([
        ccclass
    ], HiddenJoystick);
    return HiddenJoystick;
}(cc.Component));
exports.default = HiddenJoystick;

cc._RF.pop();