"use strict";
cc._RF.push(module, 'ff988278JhAMZg3JZbE+2gJ', 'ExpLabelControl');
// Script/ExpLabelControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerControl_1 = require("./PlayerControl");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.pc = null;
        return _this;
    }
    NewClass.prototype.onLoad = function () {
    };
    NewClass.prototype.start = function () {
    };
    NewClass.prototype.update = function (dt) {
        var play = this.pc.getComponent(PlayerControl_1.default);
        this.node.getComponent(cc.Label).string = play.player.lv + "";
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "pc", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();