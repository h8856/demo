"use strict";
cc._RF.push(module, '5b6a3X7rzRBPK1PHoigryFQ', 'ComponentBase');
// Script/ComponentBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ComponentBase = /** @class */ (function (_super) {
    __extends(ComponentBase, _super);
    function ComponentBase() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ComponentBase.prototype.ReceiveMessage = function (message) {
    };
    ComponentBase = __decorate([
        ccclass
    ], ComponentBase);
    return ComponentBase;
}(cc.Component));
exports.default = ComponentBase;

cc._RF.pop();