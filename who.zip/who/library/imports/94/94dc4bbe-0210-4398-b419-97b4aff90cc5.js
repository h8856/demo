"use strict";
cc._RF.push(module, '94dc4u+AhBDmLQZl7Sv+QzF', 'enemynum');
// Script/menu/enemynum.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var enemynum = /** @class */ (function (_super) {
    __extends(enemynum, _super);
    function enemynum() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    enemynum.prototype.onLoad = function () {
    };
    enemynum.prototype.start = function () {
    };
    enemynum.prototype.update = function (dt) {
        var num = cc.find("enemys").children.length;
        this.node.getComponent(cc.Label).string = num + "";
    };
    enemynum = __decorate([
        ccclass
    ], enemynum);
    return enemynum;
}(cc.Component));
exports.default = enemynum;

cc._RF.pop();