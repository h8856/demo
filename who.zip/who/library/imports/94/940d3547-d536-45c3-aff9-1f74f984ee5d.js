"use strict";
cc._RF.push(module, '940d3VH1TZFw6/5H3T5hO5d', 'PlayerControl');
// Script/PlayerControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BulletControl_1 = require("./BulletControl");
var HealthControl_1 = require("./HealthControl");
var kuwuControl_1 = require("./kuwuControl");
// import PlayerManager from "./PlayerManager";
var TimeMnanger_1 = require("./TimeMnanger");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function () {
    function Player(health, lv, exp, speed) {
        this.maxhealth = 100;
        this.health = this.maxhealth;
        this.lv = lv;
        this.exp = exp;
        this.speed = speed;
    }
    return Player;
}());
var PlayerControl = /** @class */ (function (_super) {
    __extends(PlayerControl, _super);
    function PlayerControl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bulletPrefab = null; // 子弹预制体  
        _this.kuwuPrefab = null;
        _this.enemyPrefab = null; //敌人预设体
        _this.bulletSpeed = 600; // 子弹速度
        _this.player = null;
        _this.enemiesPerSecond = 5;
        _this.experience = 0;
        _this.Weapon = 1; //武器类型
        _this.shootnum = 1; //射击频率
        _this.hurt = 100; //伤害
        _this.bulletFre = 1; //攻击间隔
        _this.Skill = null;
        return _this;
    }
    PlayerControl.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
        this.player = new Player(100, 1, 0, 200);
        cc.director.resume();
    };
    PlayerControl.prototype.up_attack = function () {
        this.hurt *= 1.5;
    };
    PlayerControl.prototype.up_atackspeed = function () {
        this.bulletFre *= 0.8;
    };
    PlayerControl.prototype.update_Weapon = function () {
        this.Weapon = 2;
    };
    PlayerControl.prototype.movespeed = function () {
        return this.player.speed;
    };
    PlayerControl.prototype.shoot = function () {
        for (var num = 0; num < this.shootnum; num++) {
            if (this.Weapon == 1) {
                // 实例化子弹  
                var bulletNode = cc.instantiate(this.bulletPrefab);
                // 设置子弹的父节点  
                bulletNode.setParent(this.node.parent);
                // 设置子弹的初始位置  
                bulletNode.position = this.node.position;
                // 默认方向：玩家朝向  
                var angle = this.node.angle; // 玩家当前角度  
                var radian = angle * (Math.PI / 180); // 弧度  
                var directionVector = cc.v2(Math.sin(radian), -Math.cos(radian)); // 默认方向向量  
                // 找到所有敌人  
                var enemies = cc.find("enemys").children;
                var playerWorldPos = this.node.convertToWorldSpaceAR(cc.Vec2.ZERO); // 玩家世界坐标  
                // 初始化变量，用于找到最近的敌人  
                var closestDistance = 400; // 初始为正无穷  
                var targetEnemy = null; // 最近敌人  
                for (var _i = 0, enemies_1 = enemies; _i < enemies_1.length; _i++) {
                    var enemyNode = enemies_1[_i];
                    if (enemyNode.active) {
                        // 获取敌人的世界坐标  
                        var enemyWorldPos = enemyNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
                        // 计算玩家和敌人之间的世界距离  
                        var distance = playerWorldPos.sub(enemyWorldPos).mag();
                        if (distance < closestDistance) {
                            closestDistance = distance;
                            targetEnemy = enemyNode;
                        }
                    }
                }
                // 如果找到了最近的敌人，根据方向计算向量  
                if (targetEnemy) {
                    var targetWorldPos = targetEnemy.convertToWorldSpaceAR(cc.Vec2.ZERO); // 敌人全局坐标  
                    directionVector = targetWorldPos.sub(playerWorldPos).normalize(); // 瞄准敌人的向量  
                }
                // 计算子弹的旋转角度  
                var bulletAngle = Math.atan2(directionVector.y, directionVector.x) * (180 / Math.PI); // 将方向向量转换为角度  
                bulletNode.angle = bulletAngle + 90;
                // 初始化子弹的方向和速度  
                bulletNode.getComponent(BulletControl_1.default).initialize(directionVector, this.bulletSpeed);
            }
            if (this.Weapon == 2) {
                // 实例化子弹  
                var bulletNode = cc.instantiate(this.kuwuPrefab);
                // 设置子弹的父节点  
                bulletNode.setParent(this.node.parent);
                // 设置子弹的初始位置  
                bulletNode.position = this.node.position;
                // 默认方向：玩家朝向  
                var angle = this.node.angle; // 玩家当前角度  
                var radian = angle * (Math.PI / 180); // 弧度  
                var directionVector = cc.v2(Math.sin(radian), -Math.cos(radian)); // 默认方向向量  
                // 找到所有敌人  
                var enemies = cc.find("enemys").children;
                var playerWorldPos = this.node.convertToWorldSpaceAR(cc.Vec2.ZERO); // 玩家世界坐标  
                // 初始化变量，用于找到最近的敌人  
                var closestDistance = 400;
                var targetEnemy = null; // 最近敌人  
                for (var _a = 0, enemies_2 = enemies; _a < enemies_2.length; _a++) {
                    var enemyNode = enemies_2[_a];
                    if (enemyNode.active) {
                        // 获取敌人的世界坐标  
                        var enemyWorldPos = enemyNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
                        // 计算玩家和敌人之间的世界距离  
                        var distance = playerWorldPos.sub(enemyWorldPos).mag();
                        if (distance < closestDistance) {
                            closestDistance = distance;
                            targetEnemy = enemyNode;
                        }
                    }
                }
                // 如果找到了最近的敌人，根据方向计算向量  
                if (targetEnemy) {
                    var targetWorldPos = targetEnemy.convertToWorldSpaceAR(cc.Vec2.ZERO); // 敌人全局坐标  
                    directionVector = targetWorldPos.sub(playerWorldPos).normalize(); // 瞄准敌人的向量  
                }
                // 计算子弹的旋转角度  
                var bulletAngle = Math.atan2(directionVector.y, directionVector.x) * (180 / Math.PI); // 将方向向量转换为角度  
                bulletNode.angle = bulletAngle + 90;
                // 初始化子弹的方向和速度  
                bulletNode.getComponent(kuwuControl_1.default).initialize(directionVector, this.bulletSpeed);
            }
        }
    };
    PlayerControl.prototype.addEnemy = function () {
        var minRadius = 500;
        var maxRadius = 800;
        for (var i = 0; i < this.enemiesPerSecond; i++) {
            var radius = Math.random() * (maxRadius - minRadius) + minRadius;
            var randomAngle = Math.random() * 2 * Math.PI;
            // 计算全局坐标  
            var enemyPosition = cc.v2(this.node.x + radius * Math.cos(randomAngle), this.node.y + radius * Math.sin(randomAngle));
            // 实例化敌人并设置其位置  
            var enemyNode = cc.instantiate(this.enemyPrefab);
            var enemyParent = cc.find("enemys"); // 获取敌人父节点  
            enemyNode.setParent(enemyParent);
            enemyNode.setScale(1, 1); // 确保敌人的缩放为正常  
            // 设置敌人的位置为全局坐标  
            enemyNode.position = enemyParent.convertToNodeSpaceAR(enemyPosition);
        }
        this.enemiesPerSecond + 1;
    };
    PlayerControl.prototype.healthup = function (hp) {
        this.player.health += hp;
        if (this.player.health >= this.player.maxhealth) {
            this.player.health = this.player.maxhealth;
        }
        cc.log(this.player.health);
    };
    PlayerControl.prototype.experience_up = function () {
        this.player.exp += 10;
        if (this.player.exp >= 100) {
            var t = this.player.exp - 100;
            this.player.exp = t;
            this.player.lv += 1;
            if (this.player.lv % 5 == 0) {
                this.Skill.active = true;
            }
        }
    };
    PlayerControl.prototype.start = function () {
        // PlayerManager.instance.RegisterReceiver(this)
        this.schedule(this.shoot, this.bulletFre);
        this.schedule(this.addEnemy, 2);
    };
    PlayerControl.prototype.ReceiveMessage = function (message) {
    };
    PlayerControl.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 101) {
            this.healthup(20);
            other.getComponent(HealthControl_1.default).die();
        }
        if (other.tag == 102) {
            this.experience_up();
            var experienceControl = other.getComponent(HealthControl_1.default);
            if (experienceControl) {
                experienceControl.die(); // 只有在组件存在时才调用  
            }
            else {
                cc.warn("ExperienceControl组件未找到");
            }
        }
        if (other.tag == 1) {
            this.player.health -= 5;
        }
    };
    PlayerControl.prototype.pause = function () {
        cc.director.pause();
    };
    PlayerControl.prototype.update = function (dt) {
        TimeMnanger_1.default.instance.time += dt; //计时器更新
    };
    __decorate([
        property(cc.Prefab)
    ], PlayerControl.prototype, "bulletPrefab", void 0);
    __decorate([
        property(cc.Prefab)
    ], PlayerControl.prototype, "kuwuPrefab", void 0);
    __decorate([
        property(cc.Prefab)
    ], PlayerControl.prototype, "enemyPrefab", void 0);
    __decorate([
        property
    ], PlayerControl.prototype, "bulletSpeed", void 0);
    __decorate([
        property(cc.Node)
    ], PlayerControl.prototype, "Skill", void 0);
    PlayerControl = __decorate([
        ccclass
    ], PlayerControl);
    return PlayerControl;
}(cc.Component));
exports.default = PlayerControl;

cc._RF.pop();