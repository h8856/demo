"use strict";
cc._RF.push(module, 'd3f1bfEHj1C6ZAVndqfd/Oo', 'Message');
// Script/Message.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Message = /** @class */ (function () {
    function Message(Type, Command, Content) {
        this.Type = Type;
        this.Command = Command;
        this.Content = Content;
    }
    Message = __decorate([
        ccclass
    ], Message);
    return Message;
}());
exports.default = Message;
var MessageType = /** @class */ (function () {
    function MessageType() {
    }
    MessageType.Type_player = 1;
    MessageType.Type_enemy = 2;
    MessageType.Type_fire = 3;
    MessageType.RefreshHp = 101;
    MessageType.RefreshPower = 103;
    return MessageType;
}());
exports.MessageType = MessageType;

cc._RF.pop();