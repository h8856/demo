"use strict";
cc._RF.push(module, 'd8944xja7VCKa67Dob07v8l', 'ManagerBase');
// Script/ManagerBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ComponentBase_1 = require("./ComponentBase");
var Message_1 = require("./Message");
var MessageCenter_1 = require("./MessageCenter");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ManagerBase = /** @class */ (function (_super) {
    __extends(ManagerBase, _super);
    function ManagerBase() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //管理的消息接受者数组
        _this.ReceiveList = [];
        return _this;
    }
    ManagerBase.prototype.onLoad = function () {
        //设置当前管理类接受的消息类型
        this.messageType = this.SetMessageType();
        MessageCenter_1.default.Managers.push(this);
    };
    //设置当前消息管理的消息类型
    ManagerBase.prototype.SetMessageType = function () {
        return Message_1.MessageType.Type_player;
    };
    //注册消息监听
    ManagerBase.prototype.RegisterReceiver = function (cb) {
        this.ReceiveList.push(cb);
        // cc.log(this.ReceiveList.length)
    };
    ManagerBase.prototype.ReceiveMessage = function (message) {
        _super.prototype.ReceiveMessage.call(this, message);
        if (message.Type != this.messageType) {
            return;
        }
        //向下层分发消息
        for (var _i = 0, _a = this.ReceiveList; _i < _a.length; _i++) {
            var cb = _a[_i];
            cb.ReceiveMessage(message);
        }
    };
    ManagerBase = __decorate([
        ccclass
    ], ManagerBase);
    return ManagerBase;
}(ComponentBase_1.default));
exports.default = ManagerBase;

cc._RF.pop();