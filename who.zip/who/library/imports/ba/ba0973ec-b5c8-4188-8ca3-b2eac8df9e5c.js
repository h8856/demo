"use strict";
cc._RF.push(module, 'ba097PstchBiIyjsurI355c', 'PauseMenu1');
// Script/menu/PauseMenu1.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.isPaused = false;
        _this.menu = null;
        return _this;
    }
    // 切换暂停状态  
    NewClass.prototype.togglePause = function () {
        this.isPaused = !this.isPaused;
        if (this.isPaused) {
            this.pauseGame();
        }
        else {
            this.resumeGame();
        }
    };
    // 暂停游戏  
    NewClass.prototype.pauseGame = function () {
        cc.director.pause();
        this.showPauseMenu();
    };
    // 恢复游戏  
    NewClass.prototype.resumeGame = function () {
        cc.director.resume();
        this.hidePauseMenu();
    };
    NewClass.prototype.showPauseMenu = function () {
        this.menu.active = true;
    };
    NewClass.prototype.hidePauseMenu = function () {
        this.menu.active = false;
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "menu", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();