"use strict";
cc._RF.push(module, '0b59cRDGT1KSbrBGhp2tCJ0', 'EnemyControl');
// Script/EnemyControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerControl_1 = require("./PlayerControl");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var enemy = /** @class */ (function () {
    function enemy(hp, lv, isdie) {
        this.hp = hp;
        this.lv = lv;
        this.isdie = isdie;
    }
    return enemy;
}());
var EnemyControl = /** @class */ (function (_super) {
    __extends(EnemyControl, _super);
    function EnemyControl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        _this.bullet_hurt = 100;
        _this.healthpre = null;
        _this.exp = null;
        _this.enemyAnimation = null;
        _this.moveSpeed = 15;
        _this.earn = 0;
        _this.HP = 100;
        return _this;
    }
    EnemyControl.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
        this.player = cc.find("player");
        var playercontrol = this.player.getComponent(PlayerControl_1.default);
        this.ene = new enemy(this.HP, 1, false);
        this.bullet_hurt = playercontrol.hurt;
        this.enemyAnimation = this.getComponent(cc.Animation);
        if (this.enemyAnimation) {
            this.playSpawnAnimation(); // 如果Animation组件存在，播放生成动画  
        }
        else {
            cc.error("未找到Animation组件，请检查");
        }
        this.schedule(this.move, 0.1);
    };
    EnemyControl.prototype.playSpawnAnimation = function () {
        // 播放生成动画  
        if (this.enemyAnimation) {
            this.enemyAnimation.play("enemyclip"); // 使用动画剪辑的名称  
        }
        else {
            cc.error("未找到 Animation 组件，请检查");
        }
    };
    EnemyControl.prototype.stopAnimation = function () {
        if (this.enemyAnimation) {
            this.enemyAnimation.stop(); // 停止当前播放的动画  
            // 或者停止特定的动画，可以指定动画的名称  
            // this.enemyAnimation.stop("enemyclip"); // 停止特定动画  
        }
        else {
            cc.error("未找到 Animation 组件，请检查");
        }
    };
    EnemyControl.prototype.start = function () {
    };
    EnemyControl.prototype.rotateTowardsPlayer = function (direction) {
        var rigidBody = this.getComponent(cc.RigidBody);
        if (!rigidBody || !this.ene.isdie)
            return;
        var angle = Math.atan2(direction.x, direction.y) * (180 / Math.PI); // 转换到角度  
        this.node.rotation = angle + 180; // 设置敌人的旋转角度  
    };
    EnemyControl.prototype.move = function (dt) {
        if (this.ene.hp > 0 && !this.ene.isdie) {
            // 获取玩家的世界坐标  
            var playerWorldPosition = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
            // 获取敌人的世界坐标  
            var enemyWorldPosition = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
            // 计算朝向玩家的方向  
            var direction = playerWorldPosition.sub(enemyWorldPosition).normalize();
            var rigidBody = this.getComponent(cc.RigidBody);
            if (rigidBody) {
                rigidBody.linearVelocity = direction.mul(this.moveSpeed); // 设置刚体的线性速度  
                this.rotateTowardsPlayer(direction); // 旋转朝向玩家  
            }
        }
    };
    EnemyControl.prototype.die = function () {
        var health = Math.random();
        this.stopAnimation();
        this.experience_init();
        if (health >= 0.9) {
            cc.log("生成爱心");
            var heal = cc.instantiate(this.healthpre);
            heal.setParent(this.node.parent);
            heal.setScale(15, 15);
            heal.position = this.node.position;
        }
        this.node.destroy(); // 动作完成后再销毁节点  
    };
    EnemyControl.prototype.experience_init = function () {
        if (this.exp) {
            var experience = cc.instantiate(this.exp);
            experience.setParent(this.node.parent);
            experience.position = this.node.position;
            experience.setScale(15, 15);
        }
        else {
            cc.error("经验Prefab未赋值，请检查");
        }
    };
    EnemyControl.prototype.getenemyisdie = function () {
        return this.ene.isdie;
    };
    EnemyControl.prototype.update = function (dt) {
        // this.move(dt); // 让敌人移动  
        if (this.ene.hp <= 0) {
            cc.director.getPhysicsManager().enabled = false;
            this.ene.hp = 0;
            this.ene.isdie = true;
            this.die();
        }
        var playercontrol = this.player.getComponent(PlayerControl_1.default);
        this.HP = 100 + 100 * 0.5 * this.ene.lv;
        if (playercontrol.player.lv % 5 == 0) {
            this.ene.lv++;
        }
    };
    EnemyControl.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 0 && this.ene.isdie == false) {
            this.ene.hp -= this.bullet_hurt;
            var action = cc.blink(0.5, 3);
            this.node.runAction(action);
        }
        if (other.tag == 202 && this.ene.isdie == false) {
            this.ene.hp -= this.bullet_hurt;
            var action = cc.blink(0.5, 3);
            this.node.runAction(action);
        }
    };
    __decorate([
        property(cc.Prefab)
    ], EnemyControl.prototype, "healthpre", void 0);
    __decorate([
        property(cc.Prefab)
    ], EnemyControl.prototype, "exp", void 0);
    EnemyControl = __decorate([
        ccclass
    ], EnemyControl);
    return EnemyControl;
}(cc.Component));
exports.default = EnemyControl;

cc._RF.pop();