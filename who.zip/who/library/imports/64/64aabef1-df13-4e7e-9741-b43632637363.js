"use strict";
cc._RF.push(module, '64aab7x3xNOfpdBtDYyY3Nj', 'HealthControl');
// Script/HealthControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var HealthControl = /** @class */ (function (_super) {
    __extends(HealthControl, _super);
    function HealthControl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // @property(PlayerControl)
        // playercontrol:PlayerControl = null;
        _this.iscolliding = false;
        return _this;
    }
    HealthControl.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    HealthControl.prototype.start = function () {
    };
    HealthControl.prototype.update = function (dt) {
    };
    HealthControl.prototype.die = function () {
        this.node.destroy();
    };
    HealthControl.prototype.onBeginContact = function (contact, self, other) {
    };
    HealthControl = __decorate([
        ccclass
    ], HealthControl);
    return HealthControl;
}(cc.Component));
exports.default = HealthControl;

cc._RF.pop();